//===========================//
// @ FileName : Function.h
// @ Report : �Լ�����
// @ Programmer : Moon's
// @ Date : 16.07.26
//===========================//

#ifndef _FUNCTION_H // ��ó�� ���ǹ�
#define _FUNCTION_H 

namespace Engine 
{

template <typename T>
void SAFE_DELETE(T& pInstance)
{	
	if(NULL != pInstance)
	{
		delete pInstance;
		pInstance = NULL;
	}
}

template <typename T>
void SAFE_DELETE_ARRAY(T& pInstance)
{	
	if(NULL != pInstance)
	{
		delete [] pInstance;
		pInstance = NULL;
	}
}

template <typename T>
void SAFE_DELETE_SINGLE(T& pInstance)
{	
	if(NULL != pInstance)
	{
		pInstance->DestroyInstance();
		pInstance = NULL;
	}
}

template <typename T>
void SAFE_RELEASE(T& pInstance)
{	
	if(NULL != pInstance)
	{
		pInstance->Release();
		pInstance = NULL;
	}
}

}

#endif

