//===========================//
// @ FileName : Engine_Macro.h
// @ Report : ��ũ��.
// @ Programmer : Moon's
// @ Date : 16.07.26
//===========================//

#ifndef _ENGINE_MACRO_H
#define _ENGINE_MACRO_H

#define BEGIN(NAMESPACE) namespace NAMESPACE {
#define END }
#define USING(NAMESPACE) using namespace NAMESPACE;

#define MSGBOX(STRING) MessageBox(NULL, TEXT(STRING), TEXT("Message"), MB_OK)

#define	NO_COPY(CLASSNAME)							\
		private:									\
		CLASSNAME(const CLASSNAME&);				\
		CLASSNAME& operator = (const CLASSNAME&);	\

#define	NO_CREATE(CLASSNAME)						\
		NO_COPY(CLASSNAME)							\
		private:									\
		CLASSNAME(void);							\

#define DECLARE_SINGLETON(CLASSNAME)				\
		NO_COPY(CLASSNAME)							\
		private:									\
		static CLASSNAME*	m_pInstance;			\
		public:										\
		static CLASSNAME* GetInstance(void);		\
		static void DestroyInstance(void);			\

#define IMPLEMENT_SINGLETON(CLASSNAME)				\
		CLASSNAME*	CLASSNAME::m_pInstance = NULL;	\
		CLASSNAME* CLASSNAME::GetInstance(void){	\
		if(NULL == m_pInstance) {					\
		m_pInstance = new CLASSNAME;}				\
		return m_pInstance;	}						\
		void CLASSNAME::DestroyInstance(void){		\
		if(NULL != m_pInstance) {					\
		delete m_pInstance; m_pInstance = NULL;}}

#ifdef __cplusplus
#define EXTERN extern "C"
#else
#define EXTERN
#endif

#ifdef ENGINE_EXPORTS
#define ENGINE_DLL _declspec(dllexport)
#else
#define ENGINE_DLL _declspec(dllimport)
#endif







#endif