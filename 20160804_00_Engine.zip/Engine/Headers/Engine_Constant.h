//===========================//
// @ FileName : Engine_Constant.h
// @ Report : Engine DLL�� ������� �����Ѵ�.
// @ Programmer : Moon's
// @ Date : 16.07.26
//===========================//

#ifndef	_ENGINE_CONSTANT_H
#define _ENGINE_CONSTANT_H

enum WINMODE {WINMODE_FULLMODE, WINMODE_WINMODE};


const D3DXVECTOR3	g_vLook = D3DXVECTOR3(0.f, 0.f, 1.f);

#endif