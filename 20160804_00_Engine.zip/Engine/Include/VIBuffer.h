//===========================//
// @ FileName : VIBuffer.h
// @ Report : ���������� �������ִ� Ŭ�������� �θ�Ŭ����
// @ Programmer : Moon's
// @ Date : 16.08.02
//===========================//

#pragma once
#include "Resource.h"

BEGIN(Engine)

EXTERN class ENGINE_DLL CVIBuffer
	: public CResource
{
public:
	enum BUFFERTYPE {TYPE_RCTEX, TYPE_CUBETEX};

public: // Getter
	void Receive_Vertices(void* pVertices);
	void Throw_Vertices(void* pVertices);
	void Throw_Indices(void* pIndices, const int& iTriCnt);

public: // General
	virtual HRESULT CreateVertexIndexBuffer(LPDIRECT3DDEVICE9 pGraphicDev);
	virtual void Render(LPDIRECT3DDEVICE9 pGraphicDev, const matrix &matWord);

public: // Clone
	virtual CComponent* Clone(void) PURE;

private: // Private Function
	void Release(void);

protected: // Member Data
	LPDIRECT3DVERTEXBUFFER9			m_pVB;
	DWORD							m_dwVtxCnt;
	DWORD							m_dwVtxSize;
	DWORD							m_dwVtxFVF;

protected:
	LPDIRECT3DINDEXBUFFER9			m_pIB;
	DWORD							m_dwIdxSize;
	DWORD							m_dwTriCnt;
	D3DFORMAT						m_IdxFmt;


public:
	explicit CVIBuffer(void);
	virtual ~CVIBuffer(void);
};

END
