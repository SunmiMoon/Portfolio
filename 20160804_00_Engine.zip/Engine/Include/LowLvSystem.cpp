#include "LowLvSystem.h"
#include "Device.h"
#include "Engine.h"
#include "ResourceMgr.h"

USING(Engine);

IMPLEMENT_SINGLETON(CLowLvSystem)

CLowLvSystem::CLowLvSystem(void)
: m_pDevice(CDevice::GetInstance())
, m_pEngine(CEngine::GetInstance())
, m_pResourceMgr(CResourceMgr::GetInstance())
{
}

CLowLvSystem::~CLowLvSystem(void)
{
	Release();
}

LPDIRECT3DDEVICE9 CLowLvSystem::GetGraphicDev(void)
{
	return m_pDevice->GetGraphicDev();
}

void CLowLvSystem::GetTransform(_D3DTRANSFORMSTATETYPE Type, matrix* pOutMatrix)
{
	return m_pDevice->GetTransform(Type, pOutMatrix);
}

void CLowLvSystem::SetRenderState(_D3DRENDERSTATETYPE Type, DWORD dwFlag)
{
	m_pDevice->SetRenderState(Type, dwFlag);
}

CComponent* CLowLvSystem::CloneResource(CResource::RESOURCETYPE Type , const TCHAR* pResourcKey)
{
	return m_pResourceMgr->CloneResource(Type, pResourcKey);
}

void Engine::CLowLvSystem::Receive_Vertices(CResource::RESOURCETYPE Type,  const TCHAR* pBufferKey, void* pVertices )
{
	m_pResourceMgr->Receive_Vertices(Type, pBufferKey, pVertices);
}

void Engine::CLowLvSystem::Throw_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices)
{
	m_pResourceMgr->Throw_Vertices(Type, pBufferKey, pVertices);
}

void Engine::CLowLvSystem::Throw_Indices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pIndices, const int& iTriCnt)
{
	m_pResourceMgr->Throw_Indices(Type, pBufferKey, pIndices, iTriCnt);

}

void CLowLvSystem::SetTransform(_D3DTRANSFORMSTATETYPE Type, const matrix* pmatrix)
{
	m_pDevice->SetTransform(Type, pmatrix);
}

HRESULT Engine::CLowLvSystem::InitSystem(HINSTANCE hInst, HWND hWnd, WINMODE Mode
										 , const _USHORT& nWinCX, const _USHORT& nWinCY)
{
	if( NULL != m_pDevice )
	{
		if( FAILED(m_pDevice->InitDevice(hWnd, Mode, nWinCX, nWinCY)))
			return E_FAIL;
	}

	if(FAILED(InitEngine()))
		return E_FAIL;

	return S_OK;
}

HRESULT Engine::CLowLvSystem::ReadyBuffers( CResource::RESOURCETYPE Type, CVIBuffer::BUFFERTYPE BuffType , const TCHAR* pResourceKey )
{
	if(FAILED(m_pResourceMgr->AddBuffer(m_pDevice->GetGraphicDev()
		, Type, BuffType, pResourceKey)))
		return E_FAIL;
	return S_OK;
}

HRESULT Engine::CLowLvSystem::ReadyTerrainBuffers(CResource::RESOURCETYPE Type, const TCHAR* pResourceKey , const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT &fUV )
{
	if(FAILED(m_pResourceMgr->AddTerrainBuffers(m_pDevice->GetGraphicDev()
		, Type, pResourceKey, wCntX, wCntZ, wItv, fUV)))
		return E_FAIL;
	return S_OK;
}

HRESULT	CLowLvSystem::InitEngine(void)
{
	if(NULL != m_pEngine)
	{
		if(FAILED(m_pEngine->InitEngine(m_pDevice->GetGraphicDev())))
			return E_FAIL;
	}
	return S_OK;
}

void CLowLvSystem::ResetResource(void)
{
	if(NULL != m_pResourceMgr)
		m_pResourceMgr->Reset();
}

void CLowLvSystem::Release(void)
{
	if(NULL != m_pEngine)
		Engine::SAFE_DELETE_SINGLE(m_pEngine);

	if(NULL != m_pDevice)
		Engine::SAFE_DELETE_SINGLE(m_pDevice);
}