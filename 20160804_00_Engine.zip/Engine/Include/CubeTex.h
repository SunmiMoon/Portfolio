//===========================//
// @ FileName : CubeTex.h
// @ Report : �ؽ��İ� ���ε� ť�긦 �����ϱ����� ���ؽ� ����
// @ Programmer : Moon's
// @ Date : 16.08.02
//===========================//

#pragma once
#include "Engine_Defines.h"
#include "VIBuffer.h"

BEGIN(Engine)

class CCubeTex 
	: public CVIBuffer

{
public: // Virtual
	virtual HRESULT CreateVertexIndexBuffer(LPDIRECT3DDEVICE9 pGraphicDev);

public: // Clone
	virtual CComponent* Clone(void);

public:
	static CVIBuffer* Create(LPDIRECT3DDEVICE9 pGraphicDev);

private:
	explicit CCubeTex(void);
public:
	virtual ~CCubeTex(void);
};

END