//===========================//
// @ FileName : Transform.h
// @ Report : ��ü�� ����������Ǽ��� ���¸� �����ϴ� Ŭ����
// @ Programmer : Moon's
// @ Date : 16.07.29
//===========================//

#pragma once
#include "Engine_Defines.h"
#include "component.h"

BEGIN(Engine)

EXTERN class ENGINE_DLL CTransform 
	: public CComponent
{
public:
	enum ANGLE {ANGLE_X, ANGLE_Y, ANGLE_Z, ANGLE_END};
public:
	void ShorePointer(TRANSFORM** ppInfo);
	const TRANSFORM* GetInfo(void) const;

public:
	HRESULT InitTransform(void);
public:
	virtual void Update(void);
public:
	static CTransform* Create(void);

private:
	TRANSFORM			m_tInfo;

public:
	explicit CTransform(void);
	virtual ~CTransform(void);
};

END