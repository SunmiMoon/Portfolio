#include "GameObject.h"
#include "Component.h"
#include "ReleaseFunctor.h"
#include "Transform.h"

USING(Engine)

CGameObject::CGameObject(void)
: m_pVertices_Local(NULL)
{
}

CGameObject::~CGameObject(void)
{
	Release();
}

const TRANSFORM* CGameObject::GetObjectInfo(void) const
{
	TCHAR		szTmp[128] = L"Transform";

	MAPCOM::const_iterator	iter = m_mapCom.begin();
	MAPCOM::const_iterator	iterEnd = m_mapCom.end();

	for (; iter != iterEnd; ++iter)
	{
		if(false == lstrcmp(iter->first, szTmp))
			return ((CTransform*)iter->second)->GetInfo();
	}
	return NULL;
}

void Engine::CGameObject::GetObjectMinMax(vec3* pMin, vec3* pMax) const
{
	*pMin = m_vMin;
	*pMax = m_vMax;
}

void CGameObject::Update(void)
{
	for_each(m_mapCom.begin(), m_mapCom.end(), CComponentFunctor_pair());
}

void CGameObject::Release(void)
{
	Engine::SAFE_DELETE_ARRAY(m_pVertices_Local);
	for_each(m_mapCom.begin(), m_mapCom.end(), CReleaseFunctor_Pair());
}