//===========================//
// @ FileName : TerrainBuffer.h
// @ Report : ������ ������ �����ϴ� ���ؽ�, �ε��� ����
// @ Programmer : Moon's
// @ Date : 16.08.03
//===========================//

#pragma once
#include "VIBuffer.h"

BEGIN(Engine)

class CTerrainBuffer
	: public CVIBuffer
{
public: // Virtual
	virtual HRESULT CreateVertexIndexBuffer(LPDIRECT3DDEVICE9 pGraphicDev);

public: // Clone
	virtual CComponent* Clone(void);

public: // static
	static CVIBuffer* Create(LPDIRECT3DDEVICE9 pGraphicDev
		, const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT& fUV);

private: // Member Data
	WORD		m_wCntX;
	WORD		m_wCntZ;
	WORD		m_wItv;
	_FLOAT		m_fUV;

private:
	BITMAPFILEHEADER	m_fh;
	BITMAPINFOHEADER	m_ih;
	DWORD*				m_pPixel;

public:
	explicit CTerrainBuffer(void);
	explicit CTerrainBuffer(const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT& fUV);
	virtual ~CTerrainBuffer(void);
};

END;