#include "LowLvSystem.h"
#include "Engine.h"
#include "Scene.h"

USING(Engine)

// ============= For LowLvSystem`s Function ============= //
// == Getter
// For Device
EXTERN ENGINE_DLL LPDIRECT3DDEVICE9 GetGraphicDev(void)
{
	return CLowLvSystem::GetInstance()->GetGraphicDev();
}

EXTERN ENGINE_DLL void GetTransform(_D3DTRANSFORMSTATETYPE Type, matrix* pOutMatrix)
{
	CLowLvSystem::GetInstance()->GetTransform(Type, pOutMatrix);
}

// For Resource
EXTERN ENGINE_DLL CComponent* CloneResource(CResource::RESOURCETYPE Type, const TCHAR* pResourcKey)
{
	return CLowLvSystem::GetInstance()->CloneResource(Type, pResourcKey);
}

EXTERN ENGINE_DLL void Receive_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices)
{
	CLowLvSystem::GetInstance()->Receive_Vertices(Type, pBufferKey, pVertices);
}

EXTERN ENGINE_DLL void Throw_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices)
{
	CLowLvSystem::GetInstance()->Throw_Vertices(Type, pBufferKey, pVertices);
}

EXTERN ENGINE_DLL void Throw_Indices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pIndices, const int& iTriCnt)
{
	CLowLvSystem::GetInstance()->Throw_Indices(Type, pBufferKey, pIndices, iTriCnt);
}

// == SETTER
EXTERN ENGINE_DLL void SetTransform(_D3DTRANSFORMSTATETYPE Type, const matrix* pMatrix)
{
	CLowLvSystem::GetInstance()->SetTransform(Type, pMatrix);
}

EXTERN ENGINE_DLL void SetRenderState(_D3DRENDERSTATETYPE Type, DWORD dwFlag)
{
	CLowLvSystem::GetInstance()->SetRenderState(Type, dwFlag);
}

// == FUNCTION
// For System.
EXTERN ENGINE_DLL HRESULT InitSystem(HINSTANCE hInst, HWND hWnd, WINMODE Mode, const _USHORT& nWinCX, const _USHORT& nWinCY)
{
	if(FAILED(CLowLvSystem::GetInstance()->InitSystem(hInst, hWnd, Mode, nWinCX, nWinCY)))
		return E_FAIL;
	return S_OK;
}

// For Resource
EXTERN ENGINE_DLL HRESULT ReadyBuffers(CResource::RESOURCETYPE Type, CVIBuffer::BUFFERTYPE BuffType
									   , const TCHAR* pResourceKey)
{
	if(FAILED(CLowLvSystem::GetInstance()->ReadyBuffers(Type, BuffType, pResourceKey)))
		return E_FAIL;
	return S_OK;
}

EXTERN ENGINE_DLL HRESULT ReadyTerrainBuffers(CResource::RESOURCETYPE Type, const TCHAR* pResourceKey 
												  , const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT& fUV)
{
	if(FAILED(CLowLvSystem::GetInstance()->ReadyTerrainBuffers(Type, pResourceKey, wCntX, wCntZ, wItv, fUV)))
		return E_FAIL;
	return S_OK;
}

EXTERN ENGINE_DLL void ResetResource(void)
{
	CLowLvSystem::GetInstance()->ResetResource();
}

// For Release
EXTERN ENGINE_DLL void System_Release(void)
{
	CLowLvSystem::DestroyInstance();
}

// ============= For Engine`s Function ============= //
//==SETTER
EXTERN ENGINE_DLL void DeleteCurrentScene(void)
{
	CEngine::GetInstance()->DeleteCurrentScene();
}

EXTERN ENGINE_DLL void SendCurrentScene(CScene* pCurrentScene)
{
	CEngine::GetInstance()->SetCurrentScene(pCurrentScene);
}

// ==FUNCTION
// For Engine
EXTERN ENGINE_DLL void Update_Engine(void)
{
	CEngine::GetInstance()->Update();
}

EXTERN ENGINE_DLL void Render_Engine(void)
{
	CEngine::GetInstance()->Render();
}