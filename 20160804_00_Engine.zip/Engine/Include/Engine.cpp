#include "Engine.h"
#include "Scene.h"
#include "Renderer.h"

USING(Engine)
IMPLEMENT_SINGLETON(CEngine)

CEngine::CEngine(void)
: m_pRenderer(NULL)
, m_pScene(NULL)
{
}

CEngine::~CEngine(void)
{
	Release();
}

CGameObject* Engine::CEngine::GetGameObject(const TCHAR* pLayerTag, const TCHAR* pObjKey)
{
	if(NULL == m_pScene)
		return NULL;
	return m_pScene->GetGameObject(pLayerTag, pObjKey);
}

CLayer* Engine::CEngine::GetLayer(const TCHAR* pLayerTag)
{	
	if(NULL == m_pScene)
		return NULL;
	return m_pScene->GetLayer(pLayerTag);
}

const TRANSFORM* CEngine::GetObjectInfo(const TCHAR* pLayerTag, const TCHAR* pObjKey, const WORD& wCnt)
{
	if(NULL != m_pScene)
		return m_pScene->GetObjectInfo(pLayerTag, pObjKey, wCnt);
	else
		return NULL;
}

void Engine::CEngine::GetObjectMinMax( vec3* pOutMin, vec3* pOutMax, const TCHAR* pLayerTag, const TCHAR* pObjKey, const WORD& wCnt /*= 0*/ )
{
	if(NULL != m_pScene)
		m_pScene->GetObjectMinMax(pOutMin, pOutMax, pLayerTag, pObjKey, wCnt);
	else
		return;
}

void CEngine::DeleteCurrentScene(void)
{
	SAFE_DELETE(m_pScene);
}

void CEngine::SetCurrentScene(CScene* pCurrentScene)
{
	if(NULL != m_pScene)
		Engine::SAFE_DELETE(m_pScene);
	m_pScene = pCurrentScene;

	m_pRenderer->SetCurrentScene(m_pScene);
}

HRESULT CEngine::InitEngine(LPDIRECT3DDEVICE9 pGraphicDev)
{
	m_pRenderer = CRenderer::Create(pGraphicDev);

	if( NULL == m_pRenderer )
	{
		Engine::SAFE_DELETE(m_pRenderer);
		return E_FAIL;
	}

	return S_OK;
}

void CEngine::Update(void)
{
	if( NULL != m_pScene )
		m_pScene->Update();
}

void CEngine::Render(void)
{
	if( NULL != m_pRenderer )
		m_pRenderer->Render();
}

void CEngine::Release(void)
{
	if( NULL != m_pScene )
		Engine::SAFE_DELETE(m_pScene);
	if( NULL != m_pRenderer )
		Engine::SAFE_DELETE(m_pRenderer);
}