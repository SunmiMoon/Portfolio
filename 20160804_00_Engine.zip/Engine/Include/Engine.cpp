#include "Engine.h"
#include "Scene.h"
#include "Renderer.h"

USING(Engine)
IMPLEMENT_SINGLETON(CEngine)

CEngine::CEngine(void)
: m_pRenderer(NULL)
, m_pScene(NULL)
{
}

CEngine::~CEngine(void)
{
	Release();
}

void CEngine::DeleteCurrentScene(void)
{
	SAFE_DELETE(m_pScene);
}

void CEngine::SetCurrentScene(CScene* pCurrentScene)
{
	if(NULL != m_pScene)
		Engine::SAFE_DELETE(m_pScene);
	m_pScene = pCurrentScene;

	m_pRenderer->SetCurrentScene(m_pScene);
}

HRESULT CEngine::InitEngine(LPDIRECT3DDEVICE9 pGraphicDev)
{
	m_pRenderer = CRenderer::Create(pGraphicDev);

	if( NULL == m_pRenderer )
	{
		Engine::SAFE_DELETE(m_pRenderer);
		return E_FAIL;
	}

	return S_OK;
}

void CEngine::Update(void)
{
	if( NULL != m_pScene )
		m_pScene->Update();
}

void CEngine::Render(void)
{
	if( NULL != m_pRenderer )
		m_pRenderer->Render();
}

void CEngine::Release(void)
{
	if( NULL != m_pScene )
		Engine::SAFE_DELETE(m_pScene);
	if( NULL != m_pRenderer )
		Engine::SAFE_DELETE(m_pRenderer);
}