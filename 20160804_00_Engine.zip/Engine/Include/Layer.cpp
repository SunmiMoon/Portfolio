#include "Layer.h"
#include "ReleaseFunctor.h"
#include "GameObject.h"

USING(Engine)

CLayer::CLayer(const TCHAR* pTag, const DWORD& dwReserveSize)
: m_HashObject(dwReserveSize)
, m_dwHashSize(dwReserveSize)
{
	lstrcpy(m_szTag, pTag);
}

CLayer::~CLayer(void)
{
	Release();
}

const TCHAR* CLayer::GetTag(void) const
{
	return m_szTag;
}

CGameObject* Engine::CLayer::GetGameObject(const TCHAR* pObjKey)
{
	Engine::CGameObject*	pGameObject = m_HashObject.Find(pObjKey, 0);

	if(NULL == pGameObject)
		return NULL;

	return pGameObject;
}

const TRANSFORM* CLayer::GetObjectInfo(const TCHAR* pObjKey, const WORD& wCnt) const
{
	Engine::CGameObject* pGameObject = m_HashObject.Find(pObjKey, wCnt);

	if( NULL == pGameObject )
		return NULL;

	return pGameObject->GetObjectInfo();
}

void CLayer::GetObjectMinMax(vec3* pMin, vec3* pMax, const TCHAR* pObjKey, const WORD& wCnt) const
{
	Engine::CGameObject* pGameObject = m_HashObject.Find(pObjKey, wCnt);

	if(NULL == pGameObject )
		return;
	pGameObject->GetObjectMinMax(pMin, pMax);
}


HRESULT CLayer::AddObject(const TCHAR* pObjKey, CGameObject* pInstance)
{
	if( NULL == pInstance )
		return E_FAIL;

	if( FAILED(m_HashObject.Insert(pObjKey, pInstance)))
		return E_FAIL;

	return S_OK;
}


HRESULT CLayer::InitLayer(void)
{
	return S_OK;
}

void CLayer::Update(void)
{
	CGameObject* pObject = m_HashObject.Find(L"BackGround");

	for( DWORD i = 0; i < m_dwHashSize; ++i )
	{
		CHashTable<CGameObject*>::PDATALIST DataList = m_HashObject.DataList(i);
		if(DataList == NULL)
			continue;
		
		CHashTable<CGameObject*>::DATALIST::iterator iter = DataList->begin();
		CHashTable<CGameObject*>::DATALIST::iterator iterEnd = DataList->end();

		for (; iter != iterEnd; ++iter)
		{
			(*iter)->Value->Update();
		}
	}
}

void CLayer::Render(void)
{
	for (DWORD i = 0; i < m_dwHashSize; ++i)
	{
		CHashTable<CGameObject*>::PDATALIST DataList = m_HashObject.DataList(i);
		if(DataList == NULL)
			continue;
		CHashTable<CGameObject*>::DATALIST::iterator iter = DataList->begin();
		CHashTable<CGameObject*>::DATALIST::iterator iterEnd = DataList->end();

		for (; iter != iterEnd; ++iter)
		{
			(*iter)->Value->Render();
		}
	}
}

CLayer* CLayer::Create(const TCHAR* pTag, const DWORD& dwReserveSize)
{
	CLayer*	pLayer = new CLayer(pTag, dwReserveSize);

	if(FAILED(pLayer->InitLayer()))
	{
		Engine::SAFE_DELETE(pLayer);
		return NULL;
	}
	return pLayer;
}

void CLayer::Release(void)
{
	for (DWORD i = 0; i < m_dwHashSize; ++i)
	{
		CHashTable<CGameObject*>::PDATALIST DataList = m_HashObject.DataList(i);
		if(DataList == NULL)
			continue;
		CHashTable<CGameObject*>::DATALIST::iterator iter = DataList->begin();
		CHashTable<CGameObject*>::DATALIST::iterator iterEnd = DataList->end();

		for (; iter != iterEnd; ++iter)
		{
			::SAFE_DELETE((*iter)->Value);
		}
	}
	m_HashObject.Clear();
}