#include "Layer.h"

USING(Engine)

CLayer::CLayer(const TCHAR* pTag)
{
	lstrcpy(m_szTag, pTag);
}

CLayer::~CLayer(void)
{
}

HRESULT CLayer::InitLayer(void)
{
	return S_OK;
}

void CLayer::Update(void)
{
}

void CLayer::Render(void)
{
}

CLayer* CLayer::Create(const TCHAR* pTag)
{
	CLayer* pLayer = new CLayer(pTag);

	if(FAILED(pLayer->InitLayer()))
	{
		Engine::SAFE_DELETE(pLayer);
		return NULL;
	}
	return pLayer;
}
