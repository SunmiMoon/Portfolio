//===========================//
// @ FileName : HashTable.h
// @ Report : HashTable�� ������ �ڷᱸ��
// @ Programmer : Moon's
// @ Date : 16.07.28
//===========================//

#include "Engine_Defines.h"

BEGIN(Engine)

template	<typename T>
class CHashTable
{
public:
	typedef struct tagDataSet
	{
		TCHAR		szTag[128];
		T			Value;
	}DATASET, *PDATASET;

public:
	HRESULT Insert(const TCHAR* pTag, T Value) 
	{
		DWORD dwIndex = Hashing(pTag);		

		if(dwIndex >= m_dwReserveSize)
			return E_FAIL;

		tagDataSet*		pDataSet = new tagDataSet;
		lstrcpy(pDataSet->szTag, pTag);
		pDataSet->Value = Value;

		if(NULL == m_Container[dwIndex])
		{
			list<tagDataSet*>*	pPointerList = new list<tagDataSet*>;

			pPointerList->push_back(pDataSet);

			m_Container[dwIndex] = pPointerList;

			return S_OK;
		}

		m_Container[dwIndex]->push_back(pDataSet);

		return S_OK;		
	}

	list<tagDataSet*>* DataList(const DWORD& wIdx)
	{		
		return m_Container[wIdx];
	}

	T Find(const TCHAR* pTag, const DWORD& dwCnt = 0) const
	{
		DWORD dwIndex = Hashing(pTag);

		if(NULL == m_Container[dwIndex])
			return NULL;

		list<tagDataSet*>::iterator	iter = m_Container[dwIndex]->begin();
		list<tagDataSet*>::iterator	iterEnd = m_Container[dwIndex]->end();

		DWORD		dwMyCnt = 0;

		for (; iter != iterEnd; ++iter)
		{
			if(!lstrcmp((*iter)->szTag, pTag))
			{
				if(dwMyCnt == dwCnt)
					return (*iter)->Value;
				++dwMyCnt;
			}
		}	
		return NULL;
	}

	void Clear(void)
	{
		_UINT		iSize = m_Container.size();

		for (_UINT i = 0; i < iSize; ++i)
		{
			if(NULL == m_Container[i])
				continue;

			list<tagDataSet*>::iterator	iterBegin = m_Container[i]->begin();

			list<tagDataSet*>::iterator	iterEnd = m_Container[i]->end();

			for (; iterBegin != iterEnd; ++iterBegin)
			{
				SAFE_DELETE(*iterBegin);
			}	
			SAFE_DELETE(m_Container[i]);
		}				
	}

	void Delete(const TCHAR* pTag, const WORD& wCnt = 0)
	{
		DWORD	dwIndex = Hashing(pTag) ;

		if(NULL != m_Container[dwIndex])
		{
			list<tagDataSet*>::iterator	iter = m_Container[dwIndex]->begin();
			list<tagDataSet*>::iterator	iterEnd = m_Container[dwIndex]->end();
			for( ; iter != iterEnd; ++iter)
			{								
					SAFE_DELETE(*iter);
					m_Container[dwIndex]->erase(iter);		
					return;
			}
		}
	}

public:
	DWORD Hashing(const TCHAR* pTag) const
	{
		DWORD dwLength = lstrlen(pTag);
		DWORD dwResult = 0;

		for (DWORD i = 0; i < dwLength; ++i)		
			dwResult += pTag[i];
		return dwResult % m_dwReserveSize;		
	}
public:
	typedef list<tagDataSet*>	DATALIST, *PDATALIST;

private:
	vector<list<tagDataSet*>*>	m_Container;
	DWORD						m_dwReserveSize;

private:
	CHashTable(void);
public:
	CHashTable(const DWORD& dwReserveSize) 
		: m_dwReserveSize(dwReserveSize)
	{
		m_Container.reserve(dwReserveSize); 
		m_Container.resize(dwReserveSize);
	}
public:
	~CHashTable(void) {}
};

END