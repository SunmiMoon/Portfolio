#include "ResourceMgr.h"
#include "ReleaseFunctor.h"
#include "Resource.h"
#include "RcTex.h"
#include "TerrainBuffer.h"
#include "CubeTex.h"

USING(Engine)

IMPLEMENT_SINGLETON(CResourceMgr)

CResourceMgr::CResourceMgr(void)
{
}

CResourceMgr::~CResourceMgr(void)
{
	Release();
}

CComponent* CResourceMgr::CloneResource(CResource::RESOURCETYPE Type, const TCHAR* pResourceKey)
{
	MAPRESOURCE::iterator	iterbegin = m_mapResource[Type].begin();
	MAPRESOURCE::iterator	iterend = m_mapResource[Type].end();

	for(; iterbegin != iterend; ++iterbegin)
	{
		if(!lstrcmp(iterbegin->first, pResourceKey))
		{
			return iterbegin->second->Clone();
		}

	}

	return NULL;
}

void CResourceMgr::Receive_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices)
{
	MAPRESOURCE::iterator iter = m_mapResource[Type].find(pBufferKey);

	if(iter == m_mapResource[Type].end())
		return ;

	((CVIBuffer*)iter->second)->Receive_Vertices(pVertices);
}

void CResourceMgr::Throw_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices)
{
	MAPRESOURCE::iterator	iter = m_mapResource[Type].find(pBufferKey);
	if(iter == m_mapResource[Type].end())
		return ;

	((CVIBuffer*)iter->second)->Throw_Vertices(pVertices);
}

void CResourceMgr::Throw_Indices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pIndices, const int& iTriCnt)
{
	MAPRESOURCE::iterator iter = m_mapResource[Type].find(pBufferKey);

	if(iter == m_mapResource[Type].end())
		return ;

	((CVIBuffer*)iter->second)->Throw_Indices(pIndices, iTriCnt);
}

HRESULT CResourceMgr::AddBuffer(LPDIRECT3DDEVICE9 pGraphicDev
								, CResource::RESOURCETYPE Type
								, CVIBuffer::BUFFERTYPE BuffType
								, const TCHAR* pResourceKey)
{
	MAPRESOURCE::iterator	iter = m_mapResource[Type].find(pResourceKey);
	if(iter != m_mapResource[Type].end())
		return E_FAIL;

	CResource*			pResource = NULL;

	switch(BuffType)
	{
	case CVIBuffer::TYPE_RCTEX:
		pResource = CRcTex::Create(pGraphicDev);
		break;
	case CVIBuffer::TYPE_CUBETEX:
		pResource = CCubeTex::Create(pGraphicDev);
		break;
	}

	if(NULL == pResource)
		return E_FAIL;

	m_mapResource[Type].insert(MAPRESOURCE::value_type(pResourceKey, pResource));
	
	return S_OK;
}

HRESULT CResourceMgr::AddTerrainBuffers(LPDIRECT3DDEVICE9 pGraphicDev
						  , CResource::RESOURCETYPE Type, const TCHAR* pResourceKey
						  , const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT &fUV)
{
	MAPRESOURCE::iterator	iter = m_mapResource[Type].find(pResourceKey);
	if(iter != m_mapResource[Type].end())
		return E_FAIL;

	CResource*			pResource = CTerrainBuffer::Create(pGraphicDev, wCntX, wCntZ, wItv, fUV);

	if(NULL == pResource)
		return E_FAIL;

	m_mapResource[Type].insert(MAPRESOURCE::value_type(pResourceKey, pResource));
	
	return S_OK;
}

void CResourceMgr::Reset(void)
{
	for_each(m_mapResource[CResource::DYNAMIC].begin(), m_mapResource[CResource::DYNAMIC].end(), CReleaseFunctor_Pair());
}

void CResourceMgr::Release(void)
{
	for (_INT i = 0; i < CResource::TYPE_END; ++i)
	{
		for_each(m_mapResource[i].begin(), m_mapResource[i].end(), CReleaseFunctor_Pair());
		m_mapResource[i].clear();
	}	

	for(VECRESOURCEKEY::iterator	iter = m_vecResourceKey.begin();
		iter != m_vecResourceKey.end();)
	{
		Engine::SAFE_DELETE(*iter);
		iter = m_vecResourceKey.erase(iter);
	}
	
	m_vecResourceKey.clear();
}
