//===========================//
// @ FileName : Resource.h
// @ Report : ��� ���ҽ��� �θ� Ŭ����
// @ Programmer : Moon's
// @ Date : 16.08.02
//===========================//

#pragma once
#include "Component.h"

BEGIN(Engine)

EXTERN class ENGINE_DLL CResource
	: public CComponent
{
public:
	enum RESOURCETYPE {STATIC, DYNAMIC, TYPE_END};

public:
	virtual CComponent*	Clone(void) PURE;

public:
	virtual void Render(LPDIRECT3DDEVICE9 pGraphicDev, const matrix& matWorld) {}
	virtual void Render(LPDIRECT3DDEVICE9 pGraphicDev, const WORD& wCnt) {}

protected:
	DWORD*				m_pRefCnt;

public:
	CResource(void);
	CResource(DWORD* pRefCnt);
	virtual ~CResource(void);
};

END