#pragma once

#include "Engine_Defines.h"

BEGIN(Engine)

class CScene;
class CRenderer
{
public:
	void SetCurrentScene(CScene* pCurrentScene);

public:
	HRESULT Initialize(LPDIRECT3DDEVICE9 pGraphicDev);
	void Render(void);

public:
	static CRenderer* Create(LPDIRECT3DDEVICE9 pGraphicDev);

private:
	LPDIRECT3DDEVICE9		m_pGraphicDev;
	CScene*					m_pCurrentScene;

private:
	void Release(void);

private:
	explicit CRenderer(void);
public:
	~CRenderer(void);
};

END