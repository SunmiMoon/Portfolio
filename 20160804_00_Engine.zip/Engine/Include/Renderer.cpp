#include "Renderer.h"
#include "Scene.h"

USING(Engine)

CRenderer::CRenderer(void)
: m_pGraphicDev(NULL)
{
}

CRenderer::~CRenderer(void)
{
	Release();
}

void CRenderer::SetCurrentScene(CScene* pCurrentScene)
{
	if( NULL != pCurrentScene )
		m_pCurrentScene = pCurrentScene;
}

HRESULT CRenderer::Initialize(LPDIRECT3DDEVICE9 pGraphicDev)
{
	if( NULL != pGraphicDev )
		m_pGraphicDev = pGraphicDev;
	else
	{
		MSGBOX("CRenderer::Initialize Failed");
		return E_FAIL;
	}

	return S_OK;
}

void CRenderer::Render(void)
{
	m_pGraphicDev->Clear(0, NULL,D3DCLEAR_STENCIL | D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(255, 0, 0, 255), 1.f, 0);
	m_pGraphicDev->BeginScene();

	if( NULL != m_pCurrentScene )
		m_pCurrentScene->Render();

	m_pGraphicDev->EndScene();
	m_pGraphicDev->Present(NULL, NULL, NULL, NULL);
}

CRenderer* CRenderer::Create(LPDIRECT3DDEVICE9 pGraphicDev)
{
	CRenderer*		pRenderer = new CRenderer;

	if(FAILED(pRenderer->Initialize(pGraphicDev)))
	{
		Engine::SAFE_DELETE(pRenderer);
		return NULL;
	}

	return pRenderer;
}

void CRenderer::Release(void)
{
}