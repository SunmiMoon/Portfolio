#include "VIBuffer.h"

USING(Engine)

CVIBuffer::CVIBuffer(void)
{
}

CVIBuffer::~CVIBuffer(void)
{
	Release();
}

void CVIBuffer::Receive_Vertices(void* pVertices)
{
	void*			pVertex = NULL;

	m_pVB->Lock(0, 0, &pVertex, 0);
	memcpy(pVertices, pVertex, m_dwVtxCnt * m_dwVtxSize);
	m_pVB->Unlock();
}

void CVIBuffer::Throw_Vertices(void* pVertices)
{
	void*			pVertex = NULL;

	m_pVB->Lock(0, 0, &pVertex, 0);
	memcpy(pVertex, pVertices, m_dwVtxCnt * m_dwVtxSize);
	m_pVB->Unlock();
}

void CVIBuffer::Throw_Indices(void* pIndices, const int& iTriCnt)
{
	void* pIndex = NULL;

	m_dwTriCnt = (DWORD)iTriCnt;

	m_pIB->Lock(0, 0, &pIndex, 0);
	memcpy(pIndex, pIndices, m_dwTriCnt * m_dwIdxSize);
	m_pIB->Unlock();
}

HRESULT CVIBuffer::CreateVertexIndexBuffer(LPDIRECT3DDEVICE9 pGraphicDev)
{
	if(FAILED(pGraphicDev->CreateVertexBuffer(m_dwVtxSize * m_dwVtxCnt, 0, m_dwVtxFVF, D3DPOOL_MANAGED
		, &m_pVB, 0)))
	{
		MSGBOX("CreateVertexBuffer Failed");
		return E_FAIL;
	}

	if(FAILED(pGraphicDev->CreateIndexBuffer(m_dwIdxSize * m_dwTriCnt, 0, m_IdxFmt, D3DPOOL_MANAGED
		, &m_pIB, 0)))
	{
		MSGBOX("CreateIndexBuffer Failed");
		return E_FAIL;
	}

	return S_OK;
}

void Engine::CVIBuffer::Render(LPDIRECT3DDEVICE9 pGraphicDev, const matrix &matWord)
{
	pGraphicDev->SetStreamSource(0, m_pVB, 0, m_dwVtxSize);
	pGraphicDev->SetFVF(m_dwVtxFVF);
	pGraphicDev->SetIndices(m_pIB);
	pGraphicDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_dwVtxCnt, 0, m_dwTriCnt);
}

void CVIBuffer::Release(void)
{
	if( NULL == *m_pRefCnt )
	{
		Engine::SAFE_RELEASE(m_pIB);
		Engine::SAFE_RELEASE(m_pVB);

		SAFE_DELETE(m_pRefCnt);
	}

	else
		--(*m_pRefCnt);
}
