//===========================//
// @ FileName : CDevice.h
// @ Report : 
// @ Programmer : Moon's
// @ Date : 16.07.26
//===========================//

#pragma once

#include "Engine_Defines.h"

BEGIN(Engine)
class CDevice
{
	DECLARE_SINGLETON(CDevice)
public: // Getter
	LPDIRECT3DDEVICE9 GetGraphicDev(void);
	void GetTransform(_D3DTRANSFORMSTATETYPE Type, matrix* pOutMatrix);

public: // Setter
	void SetRenderState(_D3DRENDERSTATETYPE Type, DWORD dwValue);
	void SetTransform(_D3DTRANSFORMSTATETYPE Type, const D3DXMATRIX* pMatrix);

public: // General
	HRESULT InitDevice(HWND hWnd, WINMODE Mode
		, const WORD& wWinCX
		, const WORD& wWinCY);

private: // Data
	LPDIRECT3D9				m_p3D;
	LPDIRECT3DDEVICE9		m_pGraphicDev;

private: // Private Function
	void Release(void);

private:
	explicit CDevice(void);

public:
	~CDevice(void);
};

END
