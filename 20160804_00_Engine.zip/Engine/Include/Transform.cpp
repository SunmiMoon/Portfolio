#include "Transform.h"

USING(Engine)

CTransform::CTransform(void)
{
}

CTransform::~CTransform(void)
{
}

void Engine::CTransform::ShorePointer(TRANSFORM** ppInfo)
{
	*ppInfo = &m_tInfo;
}

const TRANSFORM* Engine::CTransform::GetInfo(void) const
{
	return &m_tInfo;
}

HRESULT CTransform::InitTransform(void)
{
	ZeroMemory(&m_tInfo, sizeof(TRANSFORM));
	m_tInfo.vDirection = g_vLook;
	m_tInfo.vScale = D3DXVECTOR3(1.f, 1.f, 1.f);
	D3DXMatrixIdentity(&m_tInfo.matWorld);
	m_tInfo.matScale = m_tInfo.matRotX = m_tInfo.matRotY = m_tInfo.matRotZ = m_tInfo.matTrans = m_tInfo.matWorld;
	return S_OK;
}

void CTransform::Update(void)
{
	D3DXMatrixScaling(&m_tInfo.matScale, m_tInfo.vScale.x, m_tInfo.vScale.y, m_tInfo.vScale.z);
	D3DXMatrixRotationX(&m_tInfo.matRotX, m_tInfo.fAngle[ANGLE_X]);
	D3DXMatrixRotationY(&m_tInfo.matRotY, m_tInfo.fAngle[ANGLE_Y]);
	D3DXMatrixRotationZ(&m_tInfo.matRotZ, m_tInfo.fAngle[ANGLE_Z]);

	m_tInfo.matWorld = m_tInfo.matScale * m_tInfo.matRotX *m_tInfo.matRotY * m_tInfo.matRotZ * m_tInfo.matTrans;
}

CTransform* CTransform::Create(void)
{
	CTransform*	pComponent = new CTransform;

	if(FAILED(pComponent->InitTransform()))
	{
		Engine::SAFE_DELETE(pComponent);
		return NULL;
	}

	return pComponent;
}