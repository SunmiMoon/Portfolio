//===========================//
// @ FileName : ResourceMgr.h
// @ Report : ���ҽ��� �����ϴ� Ŭ����
// @ Programmer : Moon's
// @ Date : 16.08.02
//===========================//
#pragma once
#include "Engine_Defines.h"
#include "Resource.h"
#include "VIBuffer.h"

BEGIN(Engine)

class CResourceMgr
{
DECLARE_SINGLETON(CResourceMgr)
public:
	CComponent* CloneResource(CResource::RESOURCETYPE Type, const TCHAR* pResourceKey);
	void Receive_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices);
	void Throw_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices);
	void Throw_Indices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pIndices, const int& iTriCnt);

public:
	HRESULT AddBuffer(LPDIRECT3DDEVICE9 pGraphicDev
		, CResource::RESOURCETYPE Type, CVIBuffer::BUFFERTYPE BuffType
		, const TCHAR* pResourceKey);

	HRESULT AddTerrainBuffers(LPDIRECT3DDEVICE9 pGraphicDev
		, CResource::RESOURCETYPE Type, const TCHAR* pResourceKey
		, const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT &fUV);	

	void Reset(void);

private:
	void Release(void);

private:
	map<const TCHAR*, CResource*>			m_mapResource[CResource::TYPE_END]; 
	typedef map<const TCHAR*, CResource*>	MAPRESOURCE;

	vector<const TCHAR*>					m_vecResourceKey;
	typedef vector<const TCHAR*>			VECRESOURCEKEY;

private:
	TCHAR		szTextureKey[128];

private:
	CResourceMgr(void);
public:
	virtual ~CResourceMgr(void);
};

END;