//===========================//
// @ FileName : CLowLvSystem.h
// @ Report : ������ �����ý���(�׷���, ����, �Է���ġ�� �ʱ�ȭ)�� �����ϰ�
// @		: ������ �ʱ�ȭ�۾��� �����Ѵ�.
// @ Programmer : Moon's
// @ Date : 16.07.26
//===========================//

#pragma once

#include "Engine_Defines.h"
#include "Resource.h"
#include "VIBuffer.h"


BEGIN(Engine)

class CResourceMgr;
class CDevice;
class CEngine;
EXTERN class ENGINE_DLL CLowLvSystem
{
	DECLARE_SINGLETON(CLowLvSystem)

public: // Getter
	LPDIRECT3DDEVICE9 GetGraphicDev(void);
	void GetTransform(_D3DTRANSFORMSTATETYPE Type, matrix* pOutMatrix);
	CComponent* CloneResource(CResource::RESOURCETYPE Type , const TCHAR* pResourcKey);
	void Receive_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices);
	void Throw_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices);
	void Throw_Indices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pIndices, const int& iTriCnt);

public: // Setter
	void SetRenderState(_D3DRENDERSTATETYPE Type, DWORD dwFlag);
	void SetTransform(_D3DTRANSFORMSTATETYPE Type, const matrix* pmatrix);

public:
	HRESULT ReadyBuffers(CResource::RESOURCETYPE Type, CVIBuffer::BUFFERTYPE BuffType
		, const TCHAR* pResourceKey);	
	HRESULT ReadyTerrainBuffers( CResource::RESOURCETYPE Type, const TCHAR* pResourceKey , const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT &fUV);

public: // General
	HRESULT InitSystem(HINSTANCE hInst, HWND hWnd, WINMODE Mode, const _USHORT& nWinCX, const _USHORT& nWinCY);
	HRESULT	InitEngine(void);
	void ResetResource(void);

private: // Member Data
	CDevice*		m_pDevice;
	CEngine*		m_pEngine;
	CResourceMgr*		m_pResourceMgr;

private:
	void Release(void);

private:
	explicit CLowLvSystem(void);
public:
	~CLowLvSystem(void);
};

END
