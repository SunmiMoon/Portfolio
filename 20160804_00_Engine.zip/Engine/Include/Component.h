//===========================//
// @ FileName : Component.h
// @ Report : ��ü�� �̷�� ������ҵ��� �θ�Ŭ����
// @ Programmer : Moon's
// @ Date : 16.07.29
//===========================//

#pragma once
#include "Engine_Defines.h"

BEGIN(Engine)

EXTERN class ENGINE_DLL CComponent
{
public:
	virtual void Update(void) {}
	virtual void Render(LPDIRECT3DDEVICE9 pGraphicDev, const matrix& matWorld) {}
	virtual void Render(LPDIRECT3DDEVICE9 pGraphicDev, const WORD& wCnt) {}

public:
	explicit CComponent(void);
	virtual ~CComponent(void);
};

class CComponentFunctor_pair
{
public:
	template <typename T>
	void operator () (T& Value)
	{
		Value.second->Update();
	}

public:
	explicit CComponentFunctor_pair(void) {}
	~CComponentFunctor_pair(void) {}
};

class CComponentFunctor_Single
{
public:
	template <typename T>
	void operator () (T& Value)
	{
		Value->Update();
	}
public:
	explicit CComponentFunctor_Single(void) {}
	~ CComponentFunctor_Single(void) {}
};

END