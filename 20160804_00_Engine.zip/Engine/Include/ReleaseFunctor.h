#pragma once

BEGIN(Engine)

class CReleaseFunctor_Single
{
public:
	template <typename T>
	void operator () (T& Instance);
public:
	explicit CReleaseFunctor_Single() {}
};

class CReleaseFunctor_Pair
{
public:
	template <typename T>
	void operator () (T& Instance);
public:
	explicit CReleaseFunctor_Pair() {}
};

#include "ReleaseFunctor.inl"
END