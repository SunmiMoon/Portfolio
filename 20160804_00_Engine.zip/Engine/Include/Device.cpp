#include "Device.h"

USING(Engine);
IMPLEMENT_SINGLETON(CDevice)

CDevice::CDevice(void)
: m_p3D(NULL)
{
}

CDevice::~CDevice(void)
{
	Release();
}

LPDIRECT3DDEVICE9 CDevice::GetGraphicDev(void)
{
	return m_pGraphicDev;
}

void CDevice::GetTransform(_D3DTRANSFORMSTATETYPE Type, matrix* pOutMatrix)
{
	m_pGraphicDev->GetTransform(Type, pOutMatrix);
}

void CDevice::SetRenderState(_D3DRENDERSTATETYPE Type, DWORD dwValue)
{
	m_pGraphicDev->SetRenderState(Type, dwValue);
}

void CDevice::SetTransform(_D3DTRANSFORMSTATETYPE Type, const D3DXMATRIX* pMatrix)
{
	m_pGraphicDev->SetTransform(Type, pMatrix);
}

HRESULT CDevice::InitDevice(HWND hWnd, WINMODE Mode, const WORD& wWinCX, const WORD& wWinCY)
{
	// ���� ��ü�� ����.
	m_p3D = Direct3DCreate9(D3D_SDK_VERSION);

	// ��ġ�� ���������� �����´�.
	D3DCAPS9		DeviceCaps;
	ZeroMemory(&DeviceCaps, sizeof(D3DCAPS9));

	if(FAILED(m_p3D->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &DeviceCaps)))
	{
		MSGBOX("GetDeviceCaps Failed");
		return E_FAIL;
	}

	DWORD			dwBehaviorFlag = 0;

	// ��ġ�� ���������� �����Ѵ�.
	if(DeviceCaps.DevCaps &D3DDEVCAPS_HWTRANSFORMANDLIGHT)
		dwBehaviorFlag |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		dwBehaviorFlag |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	D3DPRESENT_PARAMETERS		d3dpp;
	ZeroMemory(&d3dpp, sizeof(d3dpp));

	d3dpp.BackBufferWidth = wWinCX;
	d3dpp.BackBufferHeight = wWinCY;
	d3dpp.BackBufferFormat = D3DFMT_A8R8G8B8;
	d3dpp.BackBufferCount = 1;

	d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;

	d3dpp.hDeviceWindow = hWnd;
	d3dpp.Windowed = Mode;

	d3dpp.EnableAutoDepthStencil = true;
	d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8;

	d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	// �����.
	if(FAILED(m_p3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd
		, dwBehaviorFlag, &d3dpp, &m_pGraphicDev)))
	{
		MSGBOX("CreateDevice Failed");
		return E_FAIL;
	}
	return S_OK;
}

void CDevice::Release(void)
{
	if(m_pGraphicDev)
	{
		m_pGraphicDev->Release();
		m_pGraphicDev = NULL;
	}

	if(m_p3D)
	{
		m_p3D->Release();
		m_p3D = NULL;
	}
}