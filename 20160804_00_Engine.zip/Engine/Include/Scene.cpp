#include "Scene.h"
#include "ReleaseFunctor.h"

USING(Engine)

CScene::CScene(void)
{
}

CScene::~CScene(void)
{
	Release();
}

void CScene::Update(void)
{
	for_each(m_vecLayers.begin(), m_vecLayers.end(), CLayerFunctor(CLayerFunctor::CALL_UPDATE));
}

void CScene::Render(void)
{
	for_each(m_vecLayers.begin(), m_vecLayers.end(), CLayerFunctor(CLayerFunctor::CALL_RENDER));
}

void CScene::Release(void)
{
	for_each(m_vecLayers.begin(), m_vecLayers.end(), CReleaseFunctor_Single());
}
