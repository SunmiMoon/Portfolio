#include "Scene.h"
#include "ReleaseFunctor.h"

USING(Engine)

CScene::CScene(void)
{
}

CScene::~CScene(void)
{
	Release();
}

CGameObject* Engine::CScene::GetGameObject(const TCHAR* pLayerTag, const TCHAR* pObjKey)
{
	VECLAYER::iterator	iter = find_if(m_vecLayers.begin(), m_vecLayers.end(), CFindLayer(pLayerTag));

	if(iter == m_vecLayers.end())
		return NULL;
	
	return (*iter)->GetGameObject(pObjKey);

}

CLayer* Engine::CScene::GetLayer(const TCHAR* pLayerTag)
{
	VECLAYER::iterator	iter = find_if(m_vecLayers.begin(), m_vecLayers.end(), CFindLayer(pLayerTag));

	if(iter == m_vecLayers.end())
		return NULL;

	return (*iter);
}

const TRANSFORM* Engine::CScene::GetObjectInfo( const TCHAR* pLayerTag, const TCHAR* pObjKey, const WORD& wCnt )
{
	VECLAYER::iterator	iter = find_if(m_vecLayers.begin(), m_vecLayers.end(), CFindLayer(pLayerTag));

	if(iter == m_vecLayers.end())
		return NULL;

	return (*iter)->GetObjectInfo(pObjKey, wCnt);
}

void Engine::CScene::GetObjectMinMax( vec3* pOutMin, vec3* pOutMax, const TCHAR* pLayerTag, const TCHAR* pObjKey, const WORD& wCnt /*= 0*/ )
{
	VECLAYER::iterator	iter = find_if(m_vecLayers.begin(), m_vecLayers.end(), CFindLayer(pLayerTag));

	if(iter == m_vecLayers.end())
		return;

	(*iter)->GetObjectMinMax(pOutMin, pOutMax, pObjKey, wCnt);
}

void CScene::Update(void)
{
	for_each(m_vecLayers.begin(), m_vecLayers.end(), CLayerFunctor(CLayerFunctor::CALL_UPDATE));
}

void CScene::Render(void)
{
	for_each(m_vecLayers.begin(), m_vecLayers.end(), CLayerFunctor(CLayerFunctor::CALL_RENDER));
}

void CScene::Release(void)
{
	for_each(m_vecLayers.begin(), m_vecLayers.end(), CReleaseFunctor_Single());
}
