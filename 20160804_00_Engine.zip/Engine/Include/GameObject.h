//===========================//
// @ FileName : CGameObject.h
// @ Report : Ŭ���̾�Ʈ���� ����� ��ü���� �θ� �ȴ�.
// @ Programmer : Moon's
// @ Date : 16.08.05
//===========================//

#pragma once
#include "Engine_Defines.h"

BEGIN(Engine)

class CComponent;
EXTERN class ENGINE_DLL CGameObject
{
public: // Getter
	const TRANSFORM* GetObjectInfo(void) const;
	void GetObjectMinMax(vec3* pMin, vec3* pMax) const;

public: // Virtual General
	virtual HRESULT Initialize(void) {return S_OK;}
	virtual HRESULT AddComponent(void) {return S_OK;}
	virtual void Update(void);
	virtual void Render(void) {}

	// ============================================================================================================= //

private: // Private Function.
	void Release(void);

protected: // Member Data.
	map<const TCHAR*, CComponent*>				m_mapCom;
	typedef map<const TCHAR*, CComponent*>		MAPCOM;

protected:
	void*										m_pVertices_Local;
	vec3										m_vMin, m_vMax;

public:
	explicit CGameObject(void);
	virtual ~CGameObject(void);
};

class CGameObjectFunctor
{
public:
	enum CALLFLAG {CALL_UPDATE, CALL_RENDER};
public:	
	void operator () (CGameObject* pInstance)
	{
		switch(m_Flag)
		{
		case CALL_UPDATE:
			pInstance->Update();
			break;
		case CALL_RENDER:
			pInstance->Render();
			break;
		}
	}
private:
	CALLFLAG			m_Flag;
public:
	CGameObjectFunctor(CALLFLAG Flag) : m_Flag(Flag) {}
};

END;