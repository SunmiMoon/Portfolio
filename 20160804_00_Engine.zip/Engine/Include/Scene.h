//===========================//
// @ FileName : Scene.h
// @ Report : ��鰴ü���� �θ� �ȴ�.
// @ Programmer : Moon's
// @ Date : 16.07.28
//===========================//

#pragma once
#include "Engine_Defines.h"
#include "Layer.h"

BEGIN(Engine)

class CGameObject;
EXTERN class ENGINE_DLL CScene
{
public: // Getter
	CGameObject* GetGameObject(const TCHAR* pLayerTag, const TCHAR* pObjKey);
	CLayer* GetLayer(const TCHAR* pLayerTag);
	const TRANSFORM* GetObjectInfo(const TCHAR* pLayerTag, const TCHAR* pObjKey, const WORD& wCnt);
	void GetObjectMinMax(vec3* pOutMin, vec3* pOutMax, const TCHAR* pLayerTag, const TCHAR* pObjKey, const WORD& wCnt = 0);
	
public: // virtual General
	virtual HRESULT InitScene(void)PURE;
	virtual void Update(void);
	virtual void Render(void);

protected: // Member Data
	vector<CLayer*>			m_vecLayers;
	typedef vector<CLayer*> VECLAYER;

private:
	virtual void Release(void);

public:
	explicit CScene(void);
	virtual ~CScene(void);
};

class CFindLayer
{
private:
	const TCHAR*	m_pLayerTag;
public:
	bool operator () (const CLayer* pLayer)
	{
		return 	!lstrcmp(m_pLayerTag, pLayer->GetTag());
	}
public:
	explicit CFindLayer(const TCHAR* pLayerTag) : m_pLayerTag(pLayerTag) {}
	~CFindLayer(void) {}
};

END