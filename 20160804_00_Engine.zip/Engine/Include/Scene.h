//===========================//
// @ FileName : Scene.h
// @ Report : ��鰴ü���� �θ� �ȴ�.
// @ Programmer : Moon's
// @ Date : 16.07.28
//===========================//

#pragma once
#include "Engine_Defines.h"
#include "Layer.h"

BEGIN(Engine)

EXTERN class ENGINE_DLL CScene
{
public: // virtual General
	virtual HRESULT InitiScene(void)PURE;
	virtual void Update(void);
	virtual void Render(void);

protected: // Member Data
	vector<CLayer*>			m_vecLayers;

private:
	virtual void Release(void);

public:
	explicit CScene(void);
	virtual ~CScene(void);
};

END