#include "Component.h"

USING(Engine)

CComponent::CComponent(void)
{
}

CComponent::~CComponent(void)
{
}
