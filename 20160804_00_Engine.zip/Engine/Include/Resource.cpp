#include "Resource.h"

USING(Engine)

CResource::CResource(void)
: m_pRefCnt(new DWORD(0))
{
}

CResource::CResource(DWORD* pRefCnt)
: m_pRefCnt(pRefCnt)
{
}

CResource::~CResource(void)
{
}
