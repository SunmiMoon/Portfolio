#include "TerrainBuffer.h"

USING(Engine)

CTerrainBuffer::CTerrainBuffer(void)
{
}

CTerrainBuffer::CTerrainBuffer( const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT& fUV )
: m_wCntX(wCntX)
, m_wCntZ(wCntZ)
, m_wItv(wItv)
, m_fUV(fUV)
{

}

CTerrainBuffer::~CTerrainBuffer(void)
{
}

HRESULT CTerrainBuffer::CreateVertexIndexBuffer(LPDIRECT3DDEVICE9 pGraphicDev)
{
	m_dwVtxCnt = m_wCntX * m_wCntZ;
	m_dwVtxSize = sizeof(VTXTEX);
	m_dwVtxFVF = VTXFVF_TEX;

	m_dwIdxSize = sizeof(INDEX32);
	m_IdxFmt = D3DFMT_INDEX32;
	m_dwTriCnt = (m_wCntX - 1) * (m_wCntZ -1) * 2;

	if(FAILED(CVIBuffer::CreateVertexIndexBuffer(pGraphicDev)))
		return E_FAIL;

	VTXTEX*			pVtxTex = NULL;

	m_pVB->Lock(0, 0, (void**)&pVtxTex, 0);

	DWORD			wIndex;

	for(WORD Cnt_i = 0; Cnt_i < m_wCntZ; ++Cnt_i)
	{
		for(WORD Cnt_j = 0; Cnt_j < m_wCntX; ++Cnt_j)
		{
			wIndex = Cnt_i * m_wCntX + Cnt_j;

			pVtxTex[wIndex].vPosition = vec3(_FLOAT(Cnt_j * m_wItv), 0.0f, _FLOAT(Cnt_i * m_wItv));
			pVtxTex[wIndex].vNormal = vec3(0.f, 0.f, 0.f);
			pVtxTex[wIndex].vTexUV = vec2(Cnt_j / (m_wCntX -1.f), -Cnt_i / (m_wCntZ - 1.f));
		}
	}

	INDEX32*		pIndex = NULL;

	DWORD			dwTriCnt = 0;
	vec3			vDir0, vDir1, vNormal;

	m_pIB->Lock(0, 0, (void**)&pIndex, 0);

	for(WORD Cnt_i = 0; Cnt_i < m_wCntZ -1; ++Cnt_i)
	{
		for(WORD Cnt_j = 0; Cnt_j < m_wCntX -1; ++Cnt_j)
		{
			wIndex = Cnt_i * m_wCntX + Cnt_j;

			pIndex[dwTriCnt]._1 = wIndex + m_wCntX;
			pIndex[dwTriCnt]._2 = wIndex + m_wCntX + 1;
			pIndex[dwTriCnt]._3 = wIndex + 1;

			vDir0 = pVtxTex[pIndex[dwTriCnt]._2].vPosition - pVtxTex[pIndex[dwTriCnt]._1].vPosition;
			vDir1 = pVtxTex[pIndex[dwTriCnt]._3].vPosition - pVtxTex[pIndex[dwTriCnt]._2].vPosition;
			D3DXVec3Cross(&vNormal, &vDir0, &vDir1);
			D3DXVec3Normalize(&vNormal, &vNormal);

			pVtxTex[pIndex[dwTriCnt]._1].vNormal += vNormal;
			pVtxTex[pIndex[dwTriCnt]._2].vNormal += vNormal;
			pVtxTex[pIndex[dwTriCnt]._3].vNormal += vNormal;
			++dwTriCnt;

			pIndex[dwTriCnt]._1 = wIndex + m_wCntX;
			pIndex[dwTriCnt]._2 = wIndex + 1;
			pIndex[dwTriCnt]._3 = wIndex;

			vDir0 = pVtxTex[pIndex[dwTriCnt]._2].vPosition - pVtxTex[pIndex[dwTriCnt]._1].vPosition;
			vDir1 = pVtxTex[pIndex[dwTriCnt]._3].vPosition - pVtxTex[pIndex[dwTriCnt]._2].vPosition;		
			D3DXVec3Cross(&vNormal, &vDir0, &vDir1);
			D3DXVec3Normalize(&vNormal, &vNormal);

			pVtxTex[pIndex[dwTriCnt]._1].vNormal += vNormal;
			pVtxTex[pIndex[dwTriCnt]._2].vNormal += vNormal;
			pVtxTex[pIndex[dwTriCnt]._3].vNormal += vNormal;		

			++dwTriCnt;	
		}
	}

	for( int i = 0; i < m_wCntX * m_wCntZ; ++i )
	{
		D3DXVec3Normalize(&pVtxTex[i].vNormal, &pVtxTex[i].vNormal);
	}

	m_pVB->Unlock();
	m_pIB->Unlock();

	return S_OK;
}

CComponent* CTerrainBuffer::Clone(void)
{
	CComponent* pRcTex = new CTerrainBuffer(*this);

	++(*m_pRefCnt);

	return pRcTex;
}

CVIBuffer* CTerrainBuffer::Create(LPDIRECT3DDEVICE9 pGraphicDev, const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT& fUV)
{
	CVIBuffer* pTerrainBuff = new CTerrainBuffer(wCntX, wCntZ, wItv, fUV);

	if( FAILED(pTerrainBuff->CreateVertexIndexBuffer(pGraphicDev)))
	{
		Engine::SAFE_DELETE(pTerrainBuff);
		return NULL;
	}

	return pTerrainBuff;
}