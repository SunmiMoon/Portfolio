#include "RcTex.h"

USING(Engine)

CRcTex::CRcTex(void)
{
}

CRcTex::~CRcTex(void)
{
}

HRESULT CRcTex::CreateVertexIndexBuffer(LPDIRECT3DDEVICE9 pGraphicDev)
{
	m_dwVtxCnt = 4;
	m_dwVtxSize = sizeof(VTXTEX);
	m_dwVtxFVF = VTXFVF_TEX;

	m_dwIdxSize = sizeof(INDEX16);
	m_IdxFmt = D3DFMT_INDEX16;
	m_dwTriCnt = 2;

	if(FAILED(CVIBuffer::CreateVertexIndexBuffer(pGraphicDev)))
		return E_FAIL;

	// Vertex
	VTXTEX*		pVtxTex = NULL;

	m_pVB->Lock(0, 0, (void**)&pVtxTex, 0);
	ZeroMemory(pVtxTex, m_dwVtxSize * m_dwVtxCnt);

	pVtxTex[0].vPosition = vec3(-1.f, 1.f, 0.f); // ���� ��
	pVtxTex[0].vTexUV = vec2(0.f, 0.f);

	pVtxTex[1].vPosition = vec3(1.f, 1.f, 0.f); // ������ ��
	pVtxTex[1].vTexUV = vec2(1.f, 0.f);

	pVtxTex[2].vPosition = vec3(1.f, -1.f, 0.f); // ������ �Ʒ�
	pVtxTex[2].vTexUV = vec2(1.f, 1.f);

	pVtxTex[3].vPosition = vec3(-1.f, -1.f, 0.f); // ���� �Ʒ�
	pVtxTex[3].vTexUV = vec2(0.f, 1.f);

	// Index
	INDEX16*	pIndex = NULL;
	m_pIB->Lock(0, 0, (void**)&pIndex, 0);

	pIndex[0]._1 = 0;
	pIndex[0]._2 = 1;
	pIndex[0]._3 = 2;

	pIndex[1]._1 = 0;
	pIndex[1]._2 = 2;
	pIndex[1]._3 = 3;

	vec3	vDest, vSour, vCross;

	for(DWORD i = 0; i < m_dwTriCnt; ++i )
	{
		vDest = pVtxTex[pIndex[i]._2].vPosition - pVtxTex[pIndex[i]._1].vPosition;
		vSour = pVtxTex[pIndex[i]._3].vPosition - pVtxTex[pIndex[i]._2].vPosition;
		D3DXVec3Cross(&vCross, &vDest, &vSour);

		pVtxTex[pIndex[i]._1].vNormal += vCross;
		pVtxTex[pIndex[i]._2].vNormal += vCross;
		pVtxTex[pIndex[i]._3].vNormal += vCross;
	}

	for (DWORD i = 0; i < m_dwTriCnt; ++i)	
		D3DXVec3Normalize(&pVtxTex[i].vNormal, &pVtxTex[i].vNormal);

	m_pIB->Unlock();
	m_pVB->Unlock();

	return S_OK;
}

CComponent* CRcTex::Clone(void)
{
	CComponent* pBuffer = new CRcTex(*this);

	++(*m_pRefCnt);

	return pBuffer;
}

CVIBuffer* CRcTex::Create(LPDIRECT3DDEVICE9 pGraphicDev)
{
	CVIBuffer* pBuffer = new CRcTex;

	if(FAILED(pBuffer->CreateVertexIndexBuffer(pGraphicDev)))
		Engine::SAFE_DELETE(pBuffer);

	return pBuffer;
}