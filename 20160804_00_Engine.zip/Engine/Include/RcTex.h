//===========================//
// @ FileName : RcTex.h
// @ Report : �ؽ��İ� ���εȻ簢���� �����ϴ� ���ؽ�, �ε���
// @ Programmer : Moon's
// @ Date : 16.08.02
//===========================//

#pragma once
#include "VIBuffer.h"

BEGIN(Engine)

class CRcTex
	: public CVIBuffer
{
public: // Virtual
	virtual HRESULT CreateVertexIndexBuffer(LPDIRECT3DDEVICE9 pGraphicDev);

public: // Clone
	virtual CComponent* Clone(void);

public: // Static
	static CVIBuffer* Create(LPDIRECT3DDEVICE9 pGraphicDev);

private:
	explicit CRcTex(void);
public:
	virtual ~CRcTex(void);
};

END