//===========================//
// @ FileName : Export_Function.h
// @ Report : Ŭ���̾�Ʈ���� ȣ���� �Լ����� ���հ� ����
// @ Programmer : Moon's
// @ Date : 16.07.25
//===========================//

#pragma once
#include "Engine_Defines.h"
#include "LowLvSystem.h"
#include "Layer.h"

BEGIN(Engine)

class CScene;

// ============= For LowLvSystem`s Function ============= //
// == GETTER
// For Device
EXTERN ENGINE_DLL LPDIRECT3DDEVICE9 GetGraphicDev(void);
EXTERN ENGINE_DLL void GetTransform(_D3DTRANSFORMSTATETYPE Type, matrix* pOutMatrix);

// For Time

// For Input

// For Resource
EXTERN ENGINE_DLL CComponent* CloneResource(CResource::RESOURCETYPE Type
										   , const TCHAR* pResourcKey);
EXTERN ENGINE_DLL void Receive_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices);
EXTERN ENGINE_DLL void Throw_Vertices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pVertices);
EXTERN ENGINE_DLL void Throw_Indices(CResource::RESOURCETYPE Type, const TCHAR* pBufferKey, void* pIndices, const int& iTriCnt);


// == SETTER
EXTERN ENGINE_DLL void SetTransform(_D3DTRANSFORMSTATETYPE Type, const matrix* pMatrix);
EXTERN ENGINE_DLL void SetRenderState(_D3DRENDERSTATETYPE Type, DWORD dwFlag);

// == FUNCTION
// For System.
EXTERN ENGINE_DLL HRESULT InitSystem(HINSTANCE hInst, HWND hWnd, WINMODE Mode, const _USHORT& nWinCX, const _USHORT& nWinCY);

// For Resource
EXTERN ENGINE_DLL HRESULT ReadyBuffers(CResource::RESOURCETYPE Type, CVIBuffer::BUFFERTYPE BuffType
									   , const TCHAR* pResourceKey);
EXTERN ENGINE_DLL HRESULT ReadyTerrainBuffers(CResource::RESOURCETYPE Type, const TCHAR* pResourceKey 
												  , const WORD& wCntX, const WORD& wCntZ, const WORD& wItv, const _FLOAT& fUV);
EXTERN ENGINE_DLL void ResetResource(void);

// For Release
EXTERN ENGINE_DLL void System_Release(void);

// ============= For Engine`s Function ============= //
// ==GETTER

//==SETTER
EXTERN ENGINE_DLL void DeleteCurrentScene(void);
EXTERN ENGINE_DLL void SendCurrentScene(CScene* pCurrentScene);

// ==FUNCTION
// For Engine
EXTERN ENGINE_DLL void Update_Engine(void);
EXTERN ENGINE_DLL void Render_Engine(void);

// For Frustum

// For QuadTree
END