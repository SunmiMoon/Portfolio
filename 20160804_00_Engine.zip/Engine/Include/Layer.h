//===========================//
// @ FileName : Layer.h
// @ Report : Ŭ���̾�Ʈ�� ���� �����ϴ� ���̾� ��, ���̾���� ��������
//			: �ϳ��� ���� �����Ѵٴ� �̾߱�.
// @ Programmer : Moon's
// @ Date : 16.07.28
//===========================//

#pragma once
#include "Engine_Defines.h"
#include "HashTable.h"

BEGIN(Engine)

class CGameObject;
EXTERN class ENGINE_DLL CLayer
{
	NO_COPY(CLayer);
public: // Getter
	const TCHAR* GetTag(void) const;
	CGameObject* GetGameObject(const TCHAR* pObjKey);
	const TRANSFORM* GetObjectInfo(const TCHAR* pObjKey, const WORD& wCnt) const;
	void GetObjectMinMax(vec3* pMin, vec3* pMax, const TCHAR* pObjKey, const WORD& wCnt) const;

public: // Setter
	HRESULT AddObject(const TCHAR* pObjKey, CGameObject* pInstance);

public: // General
	HRESULT InitLayer(void);
	void Update(void);
	void Render(void);

public: // Static
	static CLayer* Create(const TCHAR* pTag, const DWORD& dwReserveSize);

private: // Private Function.
	void Release(void);

private:
	TCHAR				m_szTag[128];
	DWORD									m_dwHashSize;
	CHashTable<CGameObject*>				m_HashObject;
	typedef CHashTable<CGameObject*>		HASHOBJECT;

private:
	explicit CLayer(const TCHAR* pTag, const DWORD& dwReserveSize);

public:
	~CLayer(void);
};

// Layer's Functor
class CLayerFunctor
{
public:
	enum CALLFLAG {CALL_UPDATE, CALL_RENDER};

public:
	void operator () (CLayer* pLayer)
	{
		switch(m_Flag)
		{
		case CALL_UPDATE:
			pLayer->Update();
			break;
		case CALL_RENDER:
			pLayer->Render();
			break;
		}
	}

private:
	CALLFLAG			m_Flag;
public:
	CLayerFunctor(CALLFLAG Flag) : m_Flag(Flag) {}
};

END