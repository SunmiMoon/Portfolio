//===========================//
// @ FileName : CEngine.h
// @ Report : ������, ������ ����
// @ Programmer : Moon's
// @ Date : 16.07.26
//===========================//


#pragma once

#include "Engine_Defines.h"

BEGIN(Engine)

class CScene;
class CRenderer;
class CEngine
{
	DECLARE_SINGLETON(CEngine)

public: // Set General
	void DeleteCurrentScene(void);
	void SetCurrentScene(CScene* pCurrentScene);

public:
	HRESULT InitEngine(LPDIRECT3DDEVICE9 pGraphicDev);
	void Update(void);
	void Render(void);

private:
	CRenderer*			m_pRenderer;
	CScene*				m_pScene;

private:
	void Release(void);

private:
	explicit CEngine(void);
public:
	~CEngine(void);
};

END