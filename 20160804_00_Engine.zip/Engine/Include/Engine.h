//===========================//
// @ FileName : CEngine.h
// @ Report : ������, ������ ����
// @ Programmer : Moon's
// @ Date : 16.07.26
//===========================//


#pragma once

#include "Engine_Defines.h"

BEGIN(Engine)

class CGameObject;
class CLayer;
class CScene;
class CRenderer;
class CEngine
{
	DECLARE_SINGLETON(CEngine)

public: // Getter
	CGameObject* GetGameObject(const TCHAR* pLayerTag, const TCHAR* pObjKey);
	CLayer* GetLayer(const TCHAR* pLayerTag);
	const TRANSFORM* GetObjectInfo(const TCHAR* pLayerTag, const TCHAR* pObjKey, const WORD& wCnt);
	void GetObjectMinMax(vec3* pOutMin, vec3* pOutMax, const TCHAR* pLayerTag, const TCHAR* pObjKey, const WORD& wCnt = 0);

public: // Set General
	void DeleteCurrentScene(void);
	void SetCurrentScene(CScene* pCurrentScene);
	
public: // General
	HRESULT InitEngine(LPDIRECT3DDEVICE9 pGraphicDev);
	void Update(void);
	void Render(void);

private:
	CRenderer*			m_pRenderer;
	CScene*				m_pScene;

private:
	void Release(void);

private:
	explicit CEngine(void);
public:
	~CEngine(void);
};

END