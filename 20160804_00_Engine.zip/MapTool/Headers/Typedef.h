//===========================//
// @ FileName : Typedef.h
// @ Report : �ַ� ���� �������� Ÿ���� ����
// @ Programmer : Moon's
// @ Date : 16.07.25
//===========================//

#ifndef _TYPEDEF_H
#define _TYPEDEF_H 

typedef signed char		_CHAR;
typedef unsigned char	_UCHAR;
typedef signed short	_SHORT;
typedef unsigned short	_USHORT;
typedef signed int		_INT;
typedef unsigned int	_UINT;
typedef bool			_BOOL;
typedef float			_FLOAT;
typedef double			_DOUBLE;

typedef D3DXVECTOR2		vec2;
typedef D3DXVECTOR3		vec3;
typedef D3DXVECTOR4		vec4;
typedef D3DXMATRIX		matrix;

#endif