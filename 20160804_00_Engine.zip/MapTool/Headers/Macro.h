//===========================//
// @ FileName : Macro.h
// @ Report : ��ũ��.
// @ Programmer : Moon's
// @ Date : 16.07.25
//===========================//

#ifndef _MACRO_H // ��ó�� ���ǹ�
#define _MACRO_H 

#define	NO_COPY(CLASSNAME)							\
		private:									\
		CLASSNAME(const CLASSNAME&);				\
		CLASSNAME& operator = (const CLASSNAME&);	\

#define	NO_CREATE(CLASSNAME)						\
		NO_COPY(CLASSNAME)							\
		private:									\
		CLASSNAME(void);							\

#endif