//===========================//
// @ FileName : Function.h
// @ Report : �Լ���.
// @ Programmer : Moon's
// @ Date : 16.07.25
//===========================//

#ifndef _FUNCTION_H // ��ó�� ���ǹ�
#define _FUNCTION_H 

template <typename T>
void SAFE_DELETE(T& pInstance)
{	
	if(NULL != pInstance)
	{
		delete pInstance;
		pInstance = NULL;
	}
}

template <typename T>
void SAFE_DELETE_ARRAY(T& pInstance)
{	
	if(NULL != pInstance)
	{
		delete [] pInstance;
		pInstance = NULL;
	}
}

#endif