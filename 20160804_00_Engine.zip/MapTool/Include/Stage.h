#pragma once

#include "Scene.h"

class CStage
	: public Engine::CScene
{
public:
	virtual HRESULT InitScene(void);
	virtual HRESULT ReadyResource(void);
	virtual void Update(void);
	virtual void Render(void);

public:
	static Engine::CScene* Create(void);

private:
	//HRESULT CreateEnvironmentLayer(const TCHAR* pTag);

private:
	explicit CStage(void);
public:
	~CStage(void);
};
