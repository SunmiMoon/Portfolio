#include "StdAfx.h"
#include "Stage.h"

#include "Export_Function.h"

CStage::CStage(void)
{
}

CStage::~CStage(void)
{
}

HRESULT CStage::InitScene(void)
{
	if(FAILED(ReadyResource()))
		return E_FAIL;

	Engine::SetRenderState(D3DRS_LIGHTING, FALSE);

	return S_OK;

}

HRESULT CStage::ReadyResource(void)
{
	return S_OK;
}

void CStage::Update(void)
{
	Engine::CScene::Update();
}

void CStage::Render(void)
{
	Engine::CScene::Render();
}
	
Engine::CScene* CStage::Create(void)
{
	Engine::CScene*		pScene = new CStage;

	if(FAILED(pScene->InitScene()))
	{
		Engine::SAFE_DELETE(pScene);
		return NULL;
	}
	return pScene;
}