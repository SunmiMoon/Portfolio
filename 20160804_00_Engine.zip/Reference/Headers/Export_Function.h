//===========================//
// @ FileName : Export_Function.h
// @ Report : Ŭ���̾�Ʈ���� ȣ���� �Լ����� ���հ� ����
// @ Programmer : Moon's
// @ Date : 16.07.25
//===========================//

#pragma once
#include "Engine_Defines.h"

BEGIN(Engine)

class CScene;

// ============= For LowLvSystem`s Function ============= //
// == GETTER
// For Device

// For Time

// For Input

// For Resource

// == SETTER
EXTERN ENGINE_DLL void SetRenderState(_D3DRENDERSTATETYPE Type, DWORD dwFlag);

// == FUNCTION
// For System.
EXTERN ENGINE_DLL HRESULT InitSystem(HINSTANCE hInst, HWND hWnd, WINMODE Mode, const _USHORT& nWinCX, const _USHORT& nWinCY);

// For Resource

// For Release
EXTERN ENGINE_DLL void System_Release(void);

// ============= For Engine`s Function ============= //
// ==GETTER

//==SETTER
EXTERN ENGINE_DLL void SendCurrentScene(CScene* pCurrentScene);

// ==FUNCTION
// For Engine
EXTERN ENGINE_DLL void Update_Engine(void);
EXTERN ENGINE_DLL void Render_Engine(void);

// For Frustum

// For QuadTree
END